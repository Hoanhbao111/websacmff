<?php
session_start();


$config['user_vietxforg'] = 'admin';
$config['pass_vietxforg'] = 'tuanteoteo';
if ($_SERVER['PHP_AUTH_USER'] != $config['user_vietxforg'] || $_SERVER['PHP_AUTH_PW'] != $config['pass_vietxforg']){
header('WWW-Authenticate: Basic realm="Xin vui long khai bao thong tin yeu cau truoc khi duoc chuyen den bang dang nhap"');
header('HTTP/1.0 401 Unauthorized');
 
//Trang sẽ hiển thị khi thông tin khai báo sai. (support HTML).
echo '<center>Access Denied!!!</center>';
exit;
} 



$filephp = "admin.php";

$files = basename('tuandepchai.txt');   
$so_dong = count(file('tuandepchai.txt'));   
$content = file_get_contents('tuandepchai.txt');
?>
<html>
<head>
	<title>Trang đăng nhập</title>
	<meta charset="utf-8">
	<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
</head>
<body>

<html><form method="POST" action=<?php echo $filephp ?>>
	<fieldset>
	    	
	    		


<html><form method="POST" action=<?php echo $filephp ?>>
	<fieldset>
	    		<tr>
	    			<td><input type=hidden name="KEY" size="30" value ="quit"></td>
	    		</tr>
	    		
	    		<tr>
	    			<td colspan="2" align="center"> <input name="btn_quit" type="submit" value="Thoát"></td>
	    		</tr>
	    			<tr>
	    			<td colspan="2" align="center"> <input type="submit" value="Tổng <?php echo $so_dong ?> acc"></td>
	    		</tr>
	    			<tr>
	    			<td colspan="2" align="center"> <input name="trangchu" type="submit" value="Trang Chủ"></td>
	    		</tr>
	    		<tr>
	    			<td colspan="2" align="center"> <input name="btn_delete" type="submit" value="Xóa hết acc"></td>
	    		</tr>
</fieldset>

</form></html>



   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="form-group">
                                        <label>Acc</label>
                                        <div class="form-line">
                                           <textarea class="form-control" rows="12" name="mota" placeholder="Nhập mô tả"><?php
                                           $fp = @fopen('tuandepchai.txt', "r");
					if (!$fp)
					{
						echo 'Không có dữ liệu';
					}
					else
					{
						while(!feof($fp))
    						{
                                                       echo  fgets($fp)."<br>";
                                                }
					}

                                           ?></textarea>
                                        </div>
                                    </div>
                                </div>
                <script>
                        CKEDITOR.replace( "mota" );
                </script>





	


<?php


	if (isset($_POST["btn_submit"])) {
		// lấy thông tin người dùng
		$password = $_POST["KEY"];
		//làm sạch thông tin, xóa bỏ các tag html, ký tự đặc biệt 
		//mà người dùng cố tình thêm vào để tấn công theo phương thức sql injection
		$password = strip_tags($password);
		$password = addslashes($password);
		if ($password =="") {
			echo "mật khẩu bạn không được để trống!";
		}else{
			
			if ($password!=$passcode) {
				echo "mật khẩu không đúng !";
			}else{
					$_SESSION['KEY'] = $password;
					header('Location: /'.$filephp);
			}
		}
	}
	if (isset($_POST["btn_quit"])) {
		$password = "";
		$_SESSION['KEY'] = $password;
		header('Location: /'.$filephp);
	}
		if (isset($_POST["trangchu"])) {
	
		 echo "<script>
           
            setTimeout(function(){window.location.href = '/';}, 1000)
        </script>";
	}
	if (isset($_POST["btn_delete"])) {
		if (file_exists('tuandepchai.txt'))
		{
		    unlink('tuandepchai.txt');
		     echo "<script>
           
            setTimeout(function(){window.location.href = '/admin.php';}, 2000)
        </script>";
		}
		
	}
?>
	
</body>
</html>




























































